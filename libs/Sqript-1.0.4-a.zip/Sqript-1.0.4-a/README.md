![sqript logo](/src/main/resources/logo.png "sqript logo")

# Sqript

Sqript allows to edit the behavior and the content of the game with scripts. In a few lines, you can change the gameplay, add items or blocks, display information on the screen, spawn entities, create new inputs... 

Sqript is now in development and in alpha version, so a lot of bugs are expected. Please report them on our Discord: Join us !. You will also be informed of the latest updates, and you will be helped by the community.

Sqript documentation : https://nicoszpako.github.io/Sqript/

GitHub : https://github.com/nicoszpako/Sqript
Discord : https://discord.gg/WsK746Dxsx
