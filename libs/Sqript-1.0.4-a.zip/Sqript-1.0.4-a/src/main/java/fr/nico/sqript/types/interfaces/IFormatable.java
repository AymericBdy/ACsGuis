package fr.nico.sqript.types.interfaces;

public interface IFormatable {

    public String format(String format);

}
