package fr.nico.sqript.compiling;

public enum EnumTokenType {
    EXPRESSION,
    OPERATOR,
    LEFT_PARENTHESIS,
    RIGHT_PARENTHESIS
}