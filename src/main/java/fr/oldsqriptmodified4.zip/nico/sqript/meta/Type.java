package fr.nico.sqript.meta;

import fr.nico.sqript.structures.Side;
import fr.nico.sqript.types.ScriptType;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.RUNTIME)
public @interface Type {

    String name();
    Class<? extends ScriptType>[] parsableAs();
    Side side() default Side.BOTH;

}
